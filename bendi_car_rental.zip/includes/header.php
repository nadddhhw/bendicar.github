<div class="container">
    <h2>Bendi Car Rental System</h2>
    <ul>
        <li><a href="dashboard.php">Dashboard</a></li>
        <li><a href="rental.php">Peminjaman</a></li>
        <li><a href="return.php">Pengembalian</a></li>
        <li><a href="report.php">Laporan</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</div>